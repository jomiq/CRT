CATHODE RAY LUBE
DAC driver for scanning an image buffer onto an oscilloscope
