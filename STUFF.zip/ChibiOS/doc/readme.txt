*** Documentation build procedure ***

The following software must be installed:
- Doxygen 1.8.8 or later.
- Graphviz 2.26.3 or later. The ./bin directory must be specified in the path
  in order to make Graphviz accessible by Doxygen.

Build procedure:
- Run: doxygen Doxyfile_html or Doxyfile_chm

