#! /bin/sh
st-flash write build/ch.bin 0x08000000