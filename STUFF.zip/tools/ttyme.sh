#! /bin/bash

#minicom acm0-nucleo-default
minicom acm0-nucleo-115